class Person {
    getfullname() {

    }
}

